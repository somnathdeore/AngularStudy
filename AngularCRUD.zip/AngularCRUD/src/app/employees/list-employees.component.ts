import { Component, OnInit } from '@angular/core';
import {Employee} from '../models/empployee.models';

@Component({
 // selector: 'app-list-employees',
  templateUrl: './list-employees.component.html',
  styleUrls: ['./list-employees.component.css']
})
export class ListEmployeesComponent implements OnInit {

public employees:Employee[]=[
  {
    id:1,
    name:'Mark',
    gender:'Male',
    email: 'stud1@gmail.com',
    phoneNumber: 345435435,
    dateOfBirth:new Date('10/25/1988'),
    department:'IT',
    isActive:true,
    photoPath:'../assets/images/Stud1.jpg'

  },
  {
    id:2,
    name:'Amir',
    gender:'Male',
    email: 'amir@gmail.com',
    phoneNumber:22222222,
    dateOfBirth:new Date('11/20/1988'),
    department:'Computer',
    isActive:true,
    photoPath:'../assets/images/Stud2.jpg'

  },
  {
    id:3,
    name:'Smith',
    gender:'Male',
    email: 'stud3@gmail.com',
    phoneNumber: 33333333,
    dateOfBirth:new Date('12/25/1988'),
    department:'E&TC',
    isActive:true,
    photoPath:'../assets/images/Stud3.jpg'

  }
] 


  constructor() { }

  ngOnInit() {
  }

}
